import pymysql
con=pymysql.connect(host='bngxhiqdspl2okzqukej-mysql.services.clever-cloud.com',user='u4vzxeflis0nj0oc',password='ap2YPAXq4K2tSKzzZGrx',database='bngxhiqdspl2okzqukej')
curs=con.cursor()

curs.execute("select * from Mobiles")
data=curs.fetchall()


for rec in data:
    print(rec)

con.close()    