import pymysql
con=pymysql.connect(host='bngxhiqdspl2okzqukej-mysql.services.clever-cloud.com',user='u4vzxeflis0nj0oc',password='ap2YPAXq4K2tSKzzZGrx',database='bngxhiqdspl2okzqukej')
curs=con.cursor()


try:
    nm=input('Enter ModelName:')
    curs.execute("select * from Mobiles where model='%s'"%(nm))
    data=curs.fetchone()
    print(data)
    
    if data:
        purpose=input('Enter Purpose of Mobile:')
        curs.execute("update Mobiles set purpose='%s' where model='%s'"%(purpose,nm))
        con.commit()
        print("Updated sucessfully")

except Exception as e:

    print(e)        

con.close()
