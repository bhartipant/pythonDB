import pymysql
con=pymysql.connect(host='bngxhiqdspl2okzqukej-mysql.services.clever-cloud.com',user='u4vzxeflis0nj0oc',password='ap2YPAXq4K2tSKzzZGrx',database='bngxhiqdspl2okzqukej')
curs=con.cursor()

try:
    id=input("Enter Prodid of Model:")
    curs.execute("select * from  Mobiles where prodid='%s'" %(id))
    data=curs.fetchone()
    print(data)

    if data:
        price=int(input("Enter update sales price:"))
        curs.execute("update Mobiles set sales_price='%s' where prodid='%s'" %(price,id))
        con.commit()
        print("update Sucessfuly")
    else:
        print("Invalid Mobile ID")
except Exception as e:
    print(e) 

con.close()               

        



