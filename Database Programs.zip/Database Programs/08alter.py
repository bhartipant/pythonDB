import pymysql
con=pymysql.connect(host='bngxhiqdspl2okzqukej-mysql.services.clever-cloud.com',user='u4vzxeflis0nj0oc',password='ap2YPAXq4K2tSKzzZGrx',database='bngxhiqdspl2okzqukej')
curs=con.cursor()

try:
    curs.execute("alter table Mobiles add purpose varchar(50)")
    con.commit()
    print('new coloumn created')

except:
    print('invalid data')


con.close()
