import pymysql
con=pymysql.connect(host='bngxhiqdspl2okzqukej-mysql.services.clever-cloud.com',user='u4vzxeflis0nj0oc',password='ap2YPAXq4K2tSKzzZGrx',database='bngxhiqdspl2okzqukej')
curs=con.cursor()

ram=int(input('Enter ram size:'))
rom=int(input('Enter rom size:'))

curs.execute("select Model from Mobiles where Ram={0} and Rom={1}".format(ram,rom))
data=curs.fetchall()

if data:
    print(data)
else:
    print("Not Found")

con.close()   