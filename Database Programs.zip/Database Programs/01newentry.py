import pymysql
con=pymysql.connect(host='bngxhiqdspl2okzqukej-mysql.services.clever-cloud.com',user='u4vzxeflis0nj0oc',password='ap2YPAXq4K2tSKzzZGrx',database='bngxhiqdspl2okzqukej')
curs=con.cursor()

brand=input("Enter Brand:")
model=input("Enter Model Name:")
color=input("Enter Base color:")
size=float(input("Enter Display Size:"))
rom=int(input("Enter Rom Size:"))
ram=int(input("Enter Ram Size:"))
battery=int(input("Enter Battery Capacity:"))
rating=float(input("Enter Rating:"))
price=int(input("Enter Sales Price:"))


try:
    curs.execute("insert into Mobiles(brand,model,base_color,size,rom,ram,battery_capacity,rating,sales_price) values('%s','%s','%s',.2f%,%d,%d,%d,.2f%,%d)"
                  %(brand,model,color,size,rom,ram,battery,rating,price))        
                
    con.commit()
    print("Data Enter sucessfuly")
except:
    print("Invalid data")

con.close()






