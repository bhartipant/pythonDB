import pymysql
con=pymysql.connect(host='bngxhiqdspl2okzqukej-mysql.services.clever-cloud.com',user='u4vzxeflis0nj0oc',password='ap2YPAXq4K2tSKzzZGrx',database='bngxhiqdspl2okzqukej')
curs=con.cursor()

nm=input("Enter Brand :")
curs.execute("select * from  Mobiles where brand='%s'" %(nm))
             
data=curs.fetchall()
print(data)

con.close()
