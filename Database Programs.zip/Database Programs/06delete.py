import pymysql
con=pymysql.connect(host='bngxhiqdspl2okzqukej-mysql.services.clever-cloud.com',user='u4vzxeflis0nj0oc',password='ap2YPAXq4K2tSKzzZGrx',database='bngxhiqdspl2okzqukej')
curs=con.cursor()

try:
    id=input('Enter prodid:')
    curs.execute("select * from Mobiles where prodid='%s'" %id)
    data=curs.fetchone()
    
    if data:
        print(data)
        choice=input('DO You Want to Delete Mobile Data ? (y/n):')
        if choice=='y':
            curs.execute("Delete from Mobiles where prodid='%s'" %id)
            con.commit()
            print("Data Deleted Sucessfully")
        else:
            print("Data Cancelled")
    else:
        print("Data Does not available")

except Exception as e:
    print(e)


con.close()    

    



