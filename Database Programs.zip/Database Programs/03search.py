import pymysql
con=pymysql.connect(host='bngxhiqdspl2okzqukej-mysql.services.clever-cloud.com',user='u4vzxeflis0nj0oc',password='ap2YPAXq4K2tSKzzZGrx',database='bngxhiqdspl2okzqukej')
curs=con.cursor()

nm=input('Enter Model:')
curs.execute("select * from Mobiles where model='%s'" %nm)
data=curs.fetchall()

if data:
    print(data)
else:
    print("No Model Found")

con.close()        
